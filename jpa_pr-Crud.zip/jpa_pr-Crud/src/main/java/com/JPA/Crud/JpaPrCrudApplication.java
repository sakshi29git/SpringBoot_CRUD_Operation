package com.JPA.Crud;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.*;

import com.JPA.Crud.Entities.User;
import com.JPA.Crud.Repository.UserRepository;
@SpringBootApplication
public class JpaPrCrudApplication {

	public static void main(String[] args) {
		JpaPrCrudApplication obj=new JpaPrCrudApplication();
		ApplicationContext context=SpringApplication.run(JpaPrCrudApplication.class, args);
		UserRepository userRepository=context.getBean(UserRepository.class);
		int choice;
		Scanner sc=new Scanner(System.in);
		do {
			System.out.println("1. Add data");
			System.out.println("2. Display all data");
			System.out.println("3. Update data");
			System.out.println("4. Remove Data");
			System.out.println("5. Search By Name");
			System.out.println("6. Exit");
			System.out.println("Enter Choice");
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				obj.add_data(userRepository);
				break;
				
			case 2:
				obj.disp(userRepository);
				break;
				
			case 3:
				obj.update(userRepository);
				break;
				
			case 4:
				obj.remove(userRepository);
				break;
				
			case 5:
				obj.find(userRepository);
				break;
				
			case 6:
				System.out.println("Exit");
				break;
				
			default:
				System.out.println("Wrong choice");
				break;
				
			}
		}while(choice!=6);
		
		
	}
	
	
	void find(UserRepository userRepository) {
		
		String name;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name of students: ");
		name = sc.nextLine();  // Consume newline character (if any)
		Iterable<User> obj=userRepository.findByName(name);
		if(!obj.iterator().hasNext())
		{
			System.out.println("Name not present");
		}
		else {
			obj.forEach(user->{
				System.out.println(user);
			});
		}
		
	}


	void add_data(UserRepository userRepository)
	{
		char gender;
		String name,address;
		Scanner sc=new Scanner(System.in);
		int i,n;
		System.out.println("How many data entry you wants to add: ");
		n=sc.nextInt();
		
		System.out.println("Enter " + n + "student details: ");
		User[] user=new User[n];
		ArrayList<User> obj=new ArrayList<>();
		
		for(i=0;i<n;i++)
		{
			System.out.println("Enter " + (i+1) + " student details: ");
			user[i]=new User();
			sc.nextLine();  // Read actual input
			System.out.println("Enter name of students: ");
			name = sc.nextLine();  // Consume newline character (if any)
			
			System.out.println("Enter Address: ");
			address=sc.nextLine();
			System.out.println("Enter Gender:(F/M/O");
			gender=sc.next().charAt(0);
			System.out.println();
			user[i].setName(name);
			user[i].setEmail(address);
			user[i].setGender(gender);
			obj.add(user[i]);
		}
		
		Iterable<User> user1=userRepository.saveAll(obj);
		if(user1!=null)
		{
			System.out.println("Operation Sucessfull!....");
		}
		
		else {
			System.out.println("Some error occured...");
		}
		
	}
	
	void disp(UserRepository userRepository)
	{
	
		Iterable<User> obj=userRepository.findAll();
	
		if(obj.iterator().hasNext())
		{
			obj.forEach(user->{
				System.out.println(user);
			});
		}
		
		else {
			System.out.println("Table is empty...");
		}
	}
	
	void remove(UserRepository userRepository)
	{
		int id;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id of user which to be find: ");
		id=sc.nextInt();
		Optional<User> obj=userRepository.findById(id);
		User user=obj.get();
		userRepository.delete(user);
		Optional<User> deletedUser = userRepository.findById(user.getId());
		if(deletedUser.isEmpty())
		{
			System.out.println("Operation done sucessfully...");
		}
		
		else {
			System.out.println("Some error occured...");
		}
		
	}
	
	void update(UserRepository userRepository) {
        int id;
        char gender;
        String name, address;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter id of user to be updated: ");
        id = sc.nextInt();
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            System.out.println("Enter new name: ");
            sc.nextLine(); // Consume newline character
            name = sc.nextLine();
            System.out.println("Enter new Address: ");
            address = sc.nextLine();
            System.out.println("Enter Gender:(F/M/O)");
            gender = sc.next().charAt(0);

            user.setName(name);
            user.setEmail(address);
            user.setGender(gender);
            userRepository.save(user);

            System.out.println("User with id " + id + " updated successfully.");
        } else {
            System.out.println("User with id " + id + " not found.");
        }
    }

}

	
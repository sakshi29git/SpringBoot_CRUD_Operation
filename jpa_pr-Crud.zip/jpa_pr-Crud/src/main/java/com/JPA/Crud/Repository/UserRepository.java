package com.JPA.Crud.Repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.JPA.Crud.Entities.User;

public interface UserRepository extends CrudRepository<User, Integer> {
    // You can add custom query methods here if needed
	public List<User> findByName(String name);
}
